unsigned char TimerSecFlag( void );
void Timer_Ini( void );
