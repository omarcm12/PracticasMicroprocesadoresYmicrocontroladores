#include <avr/io.h>
void UART0_putchar(char data);
char UART0_getchar( void );
void UART0_puts(char *str);
